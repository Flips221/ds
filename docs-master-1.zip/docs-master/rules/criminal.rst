###############
Criminal Rules
###############
.. note::

  Stuff
