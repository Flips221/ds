##############
Faction Rules
##############
.. note::

  Stuff
