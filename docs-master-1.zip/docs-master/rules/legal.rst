############
Legal Rules
############
.. note::

  Stuff
