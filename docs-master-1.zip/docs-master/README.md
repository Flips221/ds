# OwlGaming Documentation
The OwlGaming Documentation.

This can be found at https://docs.owlgaming.net/

If working on locally you can build the environment by using `sphinx-autobuild`

### Windows

```
pip install -r requirements.txt
pip install sphinx-autobuild
make html
```

### Linux/MacOS

```
pip install -r requirements.txt
pip install sphinx-autobuild
./Makefile html
```
